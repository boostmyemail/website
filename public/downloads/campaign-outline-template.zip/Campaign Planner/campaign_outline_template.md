# Campaign Outline: [Campaign Name]

> **Status:** Draft / Review / Final
> **Prepared By:** [Your Name / Boost My Email]

---

## Part 1: Campaign Brief

| **Field**         | **Detail**              |
| ----------------- | ----------------------- |
| **Client**        | [Company Name]          |
| **Campaign Type** | [Type]                  |
| **Campaign Goal** | [Definition of Success] |
| **Audience**      | [Target Segment]        |
| **Tone**          | [Voice Guidelines]      |
| **Date**          | [Today's Date]          |

**Known Context:** [Relevant background — churn signals, previous tests, or "None"]

---

## Part 2: Strategic Architecture

**Hypothesis:** We believe that by [doing X] for [Audience Y], we will see [Result Z] because [Psychological Trigger].

**Leverage Point:** [Why this specific angle will move the needle]

**Cost of Inaction:** [What happens if this campaign doesn't get built]

---

## Part 3: Audience & Entry Logic

- **Entry Trigger:** [The event or data change that starts this flow]
- **Audience:** [Who this is for, in one sentence — no CRM properties]
- **Goal:** [What a successful outcome looks like for a contact in this sequence]

---

## Part 4: Sequence Summary

| **#** | **Timing** | **Angle**           | **CTA**  |
| ----- | ---------- | ------------------- | -------- |
| 1     | T=0        | [3–6 word angle]    | [Action] |
| 2     | +X Days    | [3–6 word angle]    | [Action] |
| 3     | +X Days    | [3–6 word angle]    | [Action] |

---

## Part 5: Success Metrics

- **Primary KPI:** [e.g., Reactivation Rate]
- **Secondary KPIs:** [e.g., Open Rate, Click Rate, Revenue Influenced]